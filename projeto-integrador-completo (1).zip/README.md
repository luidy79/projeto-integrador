# Projeto Integrador - Produtos e Fornecedores

Projeto acadêmico de gerenciamento de Produtos, Fornecedores e Associação Produto/Fornecedor.

## Tecnologias
- Backend: Node.js, Express, SQLite
- Frontend: React
- Testes da API: Insomnia/Postman
- Banco: SQLite

## Como executar

### Backend
```bash
cd backend
npm install
npm start
```

API: http://localhost:3001

### Frontend
Em outro terminal:
```bash
cd frontend
npm install
npm start
```

Frontend: http://localhost:3000

## Rotas principais

### Produtos
- GET /api/produtos
- GET /api/produtos/:id
- POST /api/produtos
- PUT /api/produtos/:id
- DELETE /api/produtos/:id

### Fornecedores
- GET /api/fornecedores
- GET /api/fornecedores/:id
- POST /api/fornecedores
- PUT /api/fornecedores/:id
- DELETE /api/fornecedores/:id

### Associações
- GET /api/associacoes
- POST /api/associacoes
- DELETE /api/associacoes/:produtoId/:fornecedorId

## Exemplo de produto
```json
{
  "nome": "Arroz 5kg",
  "descricao": "Arroz branco tipo 1",
  "preco": 29.90,
  "codigo_barras": "7890000000001"
}
```
