const express = require('express');
const controller = require('../controllers/associacaoController');

const router = express.Router();

router.get('/', controller.listar);
router.post('/', controller.criar);
router.delete('/:produtoId/:fornecedorId', controller.excluir);

module.exports = router;
