const db = require('../database/database');

exports.listar = (req, res) => {
  db.all('SELECT * FROM produtos ORDER BY id DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.json(rows);
  });
};

exports.buscar = (req, res) => {
  db.get('SELECT * FROM produtos WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ erro: err.message });
    if (!row) return res.status(404).json({ erro: 'Produto não encontrado.' });
    res.json(row);
  });
};

exports.criar = (req, res) => {
  const { nome, descricao, preco, codigo_barras } = req.body;

  if (!nome || preco === undefined || !codigo_barras) {
    return res.status(400).json({ erro: 'Nome, preço e código de barras são obrigatórios.' });
  }

  db.run(
    'INSERT INTO produtos (nome, descricao, preco, codigo_barras) VALUES (?, ?, ?, ?)',
    [nome, descricao || '', Number(preco), codigo_barras],
    function (err) {
      if (err) return res.status(400).json({ erro: err.message });
      res.status(201).json({ id: this.lastID, mensagem: 'Produto criado com sucesso.' });
    }
  );
};

exports.atualizar = (req, res) => {
  const { nome, descricao, preco, codigo_barras } = req.body;

  if (!nome || preco === undefined || !codigo_barras) {
    return res.status(400).json({ erro: 'Nome, preço e código de barras são obrigatórios.' });
  }

  db.run(
    `UPDATE produtos
     SET nome = ?, descricao = ?, preco = ?, codigo_barras = ?
     WHERE id = ?`,
    [nome, descricao || '', Number(preco), codigo_barras, req.params.id],
    function (err) {
      if (err) return res.status(400).json({ erro: err.message });
      if (this.changes === 0) return res.status(404).json({ erro: 'Produto não encontrado.' });
      res.json({ mensagem: 'Produto atualizado com sucesso.' });
    }
  );
};

exports.excluir = (req, res) => {
  db.run('DELETE FROM produtos WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ erro: err.message });
    if (this.changes === 0) return res.status(404).json({ erro: 'Produto não encontrado.' });
    res.json({ mensagem: 'Produto excluído com sucesso.' });
  });
};
