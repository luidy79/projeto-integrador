const db = require('../database/database');

exports.listar = (req, res) => {
  db.all('SELECT * FROM fornecedores ORDER BY id DESC', [], (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.json(rows);
  });
};

exports.buscar = (req, res) => {
  db.get('SELECT * FROM fornecedores WHERE id = ?', [req.params.id], (err, row) => {
    if (err) return res.status(500).json({ erro: err.message });
    if (!row) return res.status(404).json({ erro: 'Fornecedor não encontrado.' });
    res.json(row);
  });
};

exports.criar = (req, res) => {
  const { nome, cnpj, endereco, contato } = req.body;

  if (!nome || !cnpj) {
    return res.status(400).json({ erro: 'Nome e CNPJ são obrigatórios.' });
  }

  db.run(
    'INSERT INTO fornecedores (nome, cnpj, endereco, contato) VALUES (?, ?, ?, ?)',
    [nome, cnpj, endereco || '', contato || ''],
    function (err) {
      if (err) return res.status(400).json({ erro: err.message });
      res.status(201).json({ id: this.lastID, mensagem: 'Fornecedor criado com sucesso.' });
    }
  );
};

exports.atualizar = (req, res) => {
  const { nome, cnpj, endereco, contato } = req.body;

  if (!nome || !cnpj) {
    return res.status(400).json({ erro: 'Nome e CNPJ são obrigatórios.' });
  }

  db.run(
    `UPDATE fornecedores
     SET nome = ?, cnpj = ?, endereco = ?, contato = ?
     WHERE id = ?`,
    [nome, cnpj, endereco || '', contato || '', req.params.id],
    function (err) {
      if (err) return res.status(400).json({ erro: err.message });
      if (this.changes === 0) return res.status(404).json({ erro: 'Fornecedor não encontrado.' });
      res.json({ mensagem: 'Fornecedor atualizado com sucesso.' });
    }
  );
};

exports.excluir = (req, res) => {
  db.run('DELETE FROM fornecedores WHERE id = ?', [req.params.id], function (err) {
    if (err) return res.status(500).json({ erro: err.message });
    if (this.changes === 0) return res.status(404).json({ erro: 'Fornecedor não encontrado.' });
    res.json({ mensagem: 'Fornecedor excluído com sucesso.' });
  });
};
