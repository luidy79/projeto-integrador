const db = require('../database/database');

exports.listar = (req, res) => {
  const sql = `
    SELECT
      pf.produto_id,
      p.nome AS produto,
      pf.fornecedor_id,
      f.nome AS fornecedor
    FROM produto_fornecedor pf
    INNER JOIN produtos p ON p.id = pf.produto_id
    INNER JOIN fornecedores f ON f.id = pf.fornecedor_id
    ORDER BY p.nome, f.nome
  `;

  db.all(sql, [], (err, rows) => {
    if (err) return res.status(500).json({ erro: err.message });
    res.json(rows);
  });
};

exports.criar = (req, res) => {
  const { produto_id, fornecedor_id } = req.body;

  if (!produto_id || !fornecedor_id) {
    return res.status(400).json({ erro: 'produto_id e fornecedor_id são obrigatórios.' });
  }

  db.run(
    'INSERT INTO produto_fornecedor (produto_id, fornecedor_id) VALUES (?, ?)',
    [produto_id, fornecedor_id],
    function (err) {
      if (err) return res.status(400).json({ erro: 'Associação inválida ou já existente.' });
      res.status(201).json({ mensagem: 'Produto associado ao fornecedor com sucesso.' });
    }
  );
};

exports.excluir = (req, res) => {
  db.run(
    'DELETE FROM produto_fornecedor WHERE produto_id = ? AND fornecedor_id = ?',
    [req.params.produtoId, req.params.fornecedorId],
    function (err) {
      if (err) return res.status(500).json({ erro: err.message });
      if (this.changes === 0) return res.status(404).json({ erro: 'Associação não encontrada.' });
      res.json({ mensagem: 'Associação removida com sucesso.' });
    }
  );
};
