import React, { useEffect, useState } from 'react';

const API = 'http://localhost:3001/api';

function App() {
  const [aba, setAba] = useState('produtos');
  const [produtos, setProdutos] = useState([]);
  const [fornecedores, setFornecedores] = useState([]);
  const [associacoes, setAssociacoes] = useState([]);
  const [mensagem, setMensagem] = useState('');

  const [produtoForm, setProdutoForm] = useState({
    id: null, nome: '', descricao: '', preco: '', codigo_barras: ''
  });

  const [fornecedorForm, setFornecedorForm] = useState({
    id: null, nome: '', cnpj: '', endereco: '', contato: ''
  });

  const [associacaoForm, setAssociacaoForm] = useState({
    produto_id: '', fornecedor_id: ''
  });

  useEffect(() => {
    carregarTudo();
  }, []);

  async function carregarTudo() {
    try {
      const [p, f, a] = await Promise.all([
        fetch(`${API}/produtos`).then(r => r.json()),
        fetch(`${API}/fornecedores`).then(r => r.json()),
        fetch(`${API}/associacoes`).then(r => r.json())
      ]);
      setProdutos(p);
      setFornecedores(f);
      setAssociacoes(a);
    } catch {
      setMensagem('Não foi possível conectar ao backend. Verifique se ele está rodando na porta 3001.');
    }
  }

  function aviso(texto) {
    setMensagem(texto);
    setTimeout(() => setMensagem(''), 3000);
  }

  async function salvarProduto(e) {
    e.preventDefault();
    const metodo = produtoForm.id ? 'PUT' : 'POST';
    const url = produtoForm.id ? `${API}/produtos/${produtoForm.id}` : `${API}/produtos`;
    const resposta = await fetch(url, {
      method: metodo,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...produtoForm, preco: Number(produtoForm.preco) })
    });
    const data = await resposta.json();
    if (!resposta.ok) return aviso(data.erro || 'Erro ao salvar produto.');
    aviso(data.mensagem);
    setProdutoForm({ id: null, nome: '', descricao: '', preco: '', codigo_barras: '' });
    carregarTudo();
  }

  async function excluirProduto(id) {
    if (!window.confirm('Deseja excluir este produto?')) return;
    const resposta = await fetch(`${API}/produtos/${id}`, { method: 'DELETE' });
    const data = await resposta.json();
    aviso(data.mensagem || data.erro);
    carregarTudo();
  }

  function editarProduto(p) {
    setProdutoForm(p);
    setAba('produtos');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function salvarFornecedor(e) {
    e.preventDefault();
    const metodo = fornecedorForm.id ? 'PUT' : 'POST';
    const url = fornecedorForm.id ? `${API}/fornecedores/${fornecedorForm.id}` : `${API}/fornecedores`;
    const resposta = await fetch(url, {
      method: metodo,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(fornecedorForm)
    });
    const data = await resposta.json();
    if (!resposta.ok) return aviso(data.erro || 'Erro ao salvar fornecedor.');
    aviso(data.mensagem);
    setFornecedorForm({ id: null, nome: '', cnpj: '', endereco: '', contato: '' });
    carregarTudo();
  }

  async function excluirFornecedor(id) {
    if (!window.confirm('Deseja excluir este fornecedor?')) return;
    const resposta = await fetch(`${API}/fornecedores/${id}`, { method: 'DELETE' });
    const data = await resposta.json();
    aviso(data.mensagem || data.erro);
    carregarTudo();
  }

  async function salvarAssociacao(e) {
    e.preventDefault();
    const resposta = await fetch(`${API}/associacoes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(associacaoForm)
    });
    const data = await resposta.json();
    if (!resposta.ok) return aviso(data.erro || 'Erro ao associar.');
    aviso(data.mensagem);
    setAssociacaoForm({ produto_id: '', fornecedor_id: '' });
    carregarTudo();
  }

  async function excluirAssociacao(produtoId, fornecedorId) {
    const resposta = await fetch(`${API}/associacoes/${produtoId}/${fornecedorId}`, { method: 'DELETE' });
    const data = await resposta.json();
    aviso(data.mensagem || data.erro);
    carregarTudo();
  }

  return (
    <div className="app">
      <header>
        <div>
          <h1>Projeto Integrador</h1>
          <p>Gestão de Produtos e Fornecedores</p>
        </div>
      </header>

      <nav>
        <button className={aba === 'produtos' ? 'ativo' : ''} onClick={() => setAba('produtos')}>Produtos</button>
        <button className={aba === 'fornecedores' ? 'ativo' : ''} onClick={() => setAba('fornecedores')}>Fornecedores</button>
        <button className={aba === 'associacoes' ? 'ativo' : ''} onClick={() => setAba('associacoes')}>Associação</button>
      </nav>

      {mensagem && <div className="mensagem">{mensagem}</div>}

      <main>
        {aba === 'produtos' && (
          <section>
            <div className="card">
              <h2>{produtoForm.id ? 'Editar produto' : 'Cadastrar produto'}</h2>
              <form onSubmit={salvarProduto} className="grid">
                <input placeholder="Nome *" value={produtoForm.nome}
                  onChange={e => setProdutoForm({...produtoForm, nome: e.target.value})} required />
                <input placeholder="Descrição" value={produtoForm.descricao}
                  onChange={e => setProdutoForm({...produtoForm, descricao: e.target.value})} />
                <input type="number" step="0.01" placeholder="Preço *" value={produtoForm.preco}
                  onChange={e => setProdutoForm({...produtoForm, preco: e.target.value})} required />
                <input placeholder="Código de barras *" value={produtoForm.codigo_barras}
                  onChange={e => setProdutoForm({...produtoForm, codigo_barras: e.target.value})} required />
                <div className="acoes">
                  <button className="principal" type="submit">{produtoForm.id ? 'Atualizar' : 'Cadastrar'}</button>
                  {produtoForm.id && <button type="button" onClick={() => setProdutoForm({id:null,nome:'',descricao:'',preco:'',codigo_barras:''})}>Cancelar</button>}
                </div>
              </form>
            </div>

            <div className="card">
              <h2>Produtos cadastrados</h2>
              <Tabela headers={['Nome', 'Descrição', 'Preço', 'Código', 'Ações']}>
                {produtos.map(p => (
                  <tr key={p.id}>
                    <td>{p.nome}</td><td>{p.descricao}</td>
                    <td>R$ {Number(p.preco).toFixed(2)}</td><td>{p.codigo_barras}</td>
                    <td><button onClick={() => editarProduto(p)}>Editar</button> <button className="perigo" onClick={() => excluirProduto(p.id)}>Excluir</button></td>
                  </tr>
                ))}
              </Tabela>
            </div>
          </section>
        )}

        {aba === 'fornecedores' && (
          <section>
            <div className="card">
              <h2>{fornecedorForm.id ? 'Editar fornecedor' : 'Cadastrar fornecedor'}</h2>
              <form onSubmit={salvarFornecedor} className="grid">
                <input placeholder="Nome *" value={fornecedorForm.nome}
                  onChange={e => setFornecedorForm({...fornecedorForm, nome: e.target.value})} required />
                <input placeholder="CNPJ *" value={fornecedorForm.cnpj}
                  onChange={e => setFornecedorForm({...fornecedorForm, cnpj: e.target.value})} required />
                <input placeholder="Endereço" value={fornecedorForm.endereco}
                  onChange={e => setFornecedorForm({...fornecedorForm, endereco: e.target.value})} />
                <input placeholder="Contato" value={fornecedorForm.contato}
                  onChange={e => setFornecedorForm({...fornecedorForm, contato: e.target.value})} />
                <div className="acoes">
                  <button className="principal" type="submit">{fornecedorForm.id ? 'Atualizar' : 'Cadastrar'}</button>
                  {fornecedorForm.id && <button type="button" onClick={() => setFornecedorForm({id:null,nome:'',cnpj:'',endereco:'',contato:''})}>Cancelar</button>}
                </div>
              </form>
            </div>

            <div className="card">
              <h2>Fornecedores cadastrados</h2>
              <Tabela headers={['Nome', 'CNPJ', 'Endereço', 'Contato', 'Ações']}>
                {fornecedores.map(f => (
                  <tr key={f.id}>
                    <td>{f.nome}</td><td>{f.cnpj}</td><td>{f.endereco}</td><td>{f.contato}</td>
                    <td>
                      <button onClick={() => {setFornecedorForm(f); window.scrollTo({top:0,behavior:'smooth'});}}>Editar</button>{' '}
                      <button className="perigo" onClick={() => excluirFornecedor(f.id)}>Excluir</button>
                    </td>
                  </tr>
                ))}
              </Tabela>
            </div>
          </section>
        )}

        {aba === 'associacoes' && (
          <section>
            <div className="card">
              <h2>Associar produto a fornecedor</h2>
              <form onSubmit={salvarAssociacao} className="grid">
                <select value={associacaoForm.produto_id}
                  onChange={e => setAssociacaoForm({...associacaoForm, produto_id: e.target.value})} required>
                  <option value="">Selecione um produto</option>
                  {produtos.map(p => <option key={p.id} value={p.id}>{p.nome}</option>)}
                </select>
                <select value={associacaoForm.fornecedor_id}
                  onChange={e => setAssociacaoForm({...associacaoForm, fornecedor_id: e.target.value})} required>
                  <option value="">Selecione um fornecedor</option>
                  {fornecedores.map(f => <option key={f.id} value={f.id}>{f.nome}</option>)}
                </select>
                <div className="acoes">
                  <button className="principal" type="submit">Associar</button>
                </div>
              </form>
            </div>

            <div className="card">
              <h2>Associações existentes</h2>
              <Tabela headers={['Produto', 'Fornecedor', 'Ações']}>
                {associacoes.map(a => (
                  <tr key={`${a.produto_id}-${a.fornecedor_id}`}>
                    <td>{a.produto}</td><td>{a.fornecedor}</td>
                    <td><button className="perigo" onClick={() => excluirAssociacao(a.produto_id, a.fornecedor_id)}>Desassociar</button></td>
                  </tr>
                ))}
              </Tabela>
            </div>
          </section>
        )}
      </main>

      <footer>Projeto Integrador • Faculdade Gran</footer>
    </div>
  );
}

function Tabela({ headers, children }) {
  return (
    <div className="tabela-wrap">
      <table>
        <thead><tr>{headers.map(h => <th key={h}>{h}</th>)}</tr></thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}

export default App;
